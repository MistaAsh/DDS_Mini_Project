## <b> Pre-test</b>
#### Please attempt the following questions

Q 1. Which of the following test measures the toughness of road aggregates?  
<b>a) Impact test</b>  
b) Abrasion test  
c) Crushing test  
d) Shape test  

Q 2. Set of sieves used in this experiment is?  
a) 12.5mm, 20mm, 10mm  
<b> b)12.5mm, 10mm, 2.36mm </b>  
c) 10mm, 12mm, 12.5mm  
d) 2.36mm, 4.75mm, 10mm  

Q 3. What is diameter of cyclinder metal measure used in this experiment?  
<b>a) 75mm</b>  
b) 65mm  
c) 45mm  
d) 60mm  

Q 4. Impact value of aggregate satisfactory for road surfacing is  
a)  <10%  
<b>b) 20-30% </b>  
c) 30-40%  
d) >50%  

Q 5. Aggregate impact value of less than 45% is suitable for  
a) Bitumen Bound Macadam Base Course  
<b>b) WBM Base Course</b>   
c) Concrete Base Course
d) None of the above  
