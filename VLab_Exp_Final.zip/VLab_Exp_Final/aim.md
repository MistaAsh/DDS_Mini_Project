To evaluate the toughness of aggregates to break down under application of impact and to determine aggregate impact value of the given sample of aggregate. 
