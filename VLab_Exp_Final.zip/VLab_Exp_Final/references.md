### Lagu paTa:

#### Simulation Demo:
<li><a href="https://youtu.be/K_rEusMExv4">https://youtu.be/K_rEusMExv4</a></li>

<table style="text-align:justify;margin-top:15px;">
<tr style="background-color: white">
<th>References</th>
<th>Contributors list</th>
</tr>
<tr style="text-align:justify;padding-top:0px;background-color: white">
<td style="text-align:justify;padding-top:0px">
<ol style="padding-top:0px">
<li>IS 2386 (Part IV) 1963: Methods of test for aggregates mechanical properties, Tenth Reprint MARCH 1997.</li>
<li>IS 383-1970: Specification for coarse and fine aggregates.</li>
<li>L. R. Kadiyali, Transportation Engineering, Khanna Publishing, 2016.</li>
<li>N. L. Arora, A Textbook of Transportation Engineering, New India Publication, 1997.</li>
<li>Road Aggregates their Uses and Testing B.H knight and R.G Knight.</li>
<li>Indian Standard Methods of Test for Aggregates for Concrete IS: 2386 Part IV.</li>
<li>Standard Specifications and Code of Practice for Construction of Concrete Roads, IRC: 15-1970, Indian Road Congress.</li>
<li>Specification for Aggregates Impact Value IS: 2386- PART IV-1963.</li>
<li>Specification for Fine and Coarse Aggregates IS: 383-1970.</li>
</ol>
</td>
<td style="text-align:justify;padding-top:0px">Developer: Dr. Pruthviraj U | NITK</br>
Contributors:
<ul style="list-style-type: none;">
<li>Akshaya | NITK</li>
<li>Swathi Shetty | NITK</li>
<li>Aishwarya Shetty | NITK</li>
<li>Aishwarya Hegde | NITK</li>
<li>H.D Sumanth (16Cv114) | NITK</li>
<li>Ujwal M (16CV146) | NITK</li>
<li>Vathan K (16CV147) | NITK</li>
<li>Sushamitha Wadde | NITK</li>
</ul></td>
</tr>
</table>


