## Post test  
Q 1. What is depth of the cyclindrical metal measure used in this experiment?                
a. 45mm   
<b>b. 50mm</b>  
c. 55mm  
d. 60mm    

Q 2. What is the use of Impact Test?   
a. Resistance of an aggregates to loads  
b. Resistance of aggregates under loads   
<b>c. Resistance of aggregates to sudden impact</b>  
d. Resistance of aggregates to abrasion  

Q 3. What should be the Impact Value of aggregates used in concrete?   
<b>a. Not less than 40%</b>   
b. Not less than 45%
c. More than 50%  
d. More 55%  

Q 4. Which property of the material is used to resist Impact?   
a. Strength  
b. Durability  
<b>c. Toughness</b>  
d. Abrasion  

Q 5.  Aggregate can be said as strong, when the impact value is very less. (Say True or False)  
<b>a. True</b>  
b. Flase  
